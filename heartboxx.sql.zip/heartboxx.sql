-- phpMyAdmin SQL Dump
-- version 4.1.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 01, 2016 at 06:34 AM
-- Server version: 5.5.41-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `heartboxx`
--

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `venue_name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `ll` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `confirmed_presence` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `venue_name`, `category`, `city`, `uid`, `ll`, `created_at`, `confirmed_presence`) VALUES
(1, 'dfd', 'lkj', 'lkj', 25, '', '0000-00-00 00:00:00', 0),
(2, 'Pettai Railway station', 'Train Station', '', 2, '8.72,77.65', '2016-04-30 11:54:05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`id`, `description`, `created_at`) VALUES
(25, '', '2016-04-30 09:21:42'),
(26, 'CLLocationCoordinate2D(latitude: 8.7204624602955523, longitude: 77.651997372352255)', '2016-04-30 09:22:36'),
(27, '', '2016-04-30 11:52:27'),
(28, '', '2016-04-30 11:52:57'),
(29, '', '2016-04-30 11:54:05'),
(30, 'coming baby', '2016-04-30 11:54:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `gender` char(1) NOT NULL,
  `city` varchar(50) NOT NULL,
  `bio` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`, `status`, `gender`, `city`, `bio`, `created_at`) VALUES
(1, 'dfdf', '', 'sfd@dfs.sdf', 'sdfsdf', 0, '', '', '', '0000-00-00 00:00:00'),
(2, 'sdfsf', '', 'ww222@df.fde', 'sfds', 0, '', '', '', '0000-00-00 00:00:00'),
(4, '', '', 'jak@gdf.df', '5f4dcc3b5aa765d61d8327deb882cf99', 1, '', '', '', '2016-04-30 15:17:51'),
(27, 'kf', 'lanam', 'jak@gdf.dfj', '5f4dcc3b5aa765d61d8327deb882cf99', 1, 'M', 'cicy', 'dhdhd', '2016-04-30 15:59:29');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
